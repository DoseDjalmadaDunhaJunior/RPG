package com.company;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Salva oi = new Salva();

        //para criar uma pasta caso nao exista, caso exista ela sera impressa no terminal
        oi.criaPasta();

        /*precisa-se de 2 vetores iguais um apenas com o nome de cada atributo e outro com os valores deles
        todos em String e pode-se passar de todos os jogadores de uma unica vez e junto
         */

        String[] nome = new String[10];
        String[] atributos = new String[10];
        nome[0] = "Nome";
        nome[1] = "HP";
        nome[2] = "Classe";
        nome[3] = "Forca";
        nome[4] = "Inteligencia";
        nome[5] = "Nome";
        nome[6] = "HP";
        nome[7] = "Classe";
        nome[8] = "Forca";
        nome[9] = "Inteligencia";
        atributos[0] = "Jogador 1";
        atributos[1] = "10";
        atributos[2] = "android";
        atributos[3] = "50";
        atributos[4] = "100";
        atributos[5] = "Jogador 2";
        atributos[6] = "50";
        atributos[7] = "mago";
        atributos[8] = "5";
        atributos[9] = "100";

        /*
        envia-se primeiro o nome da caracteristica depois o valor, depois quantas classes cada jogador tem
        depois quantos jogadores estao na partida
         */

        oi.gravar(nome, atributos, 5, 2);

        //para mostrar os arquivos existentes
        oi.listar();

        //basta inserir o nome do arquivo de save para ele pegar os dados de volta

        oi.le("exemplo1");

        /*
        ate o for os dados os dados abaixo sao apenas para comprovar que foi salvo e é possivel movimentar os dados
        obtidos dos arquivos
         */
        String[] nomePopulado;
        String[] atributosPopulado;
        nomePopulado = oi.getNomeClasse();
        atributosPopulado = oi.getValorClasse();
        for (int i = 0; i < 10; i++) {
            System.out.println(nomePopulado[i] + " " + atributosPopulado[i]);
        }

        oi.apaga("exemplo1");
        oi.listar();
    }
}
