package com.company;

import java.io.*;
import java.util.Scanner;

public class Salva {
    /*essa funcao cria um diretorio(pasta) com um nome que com certeza so o nosso programa fara
    e caso a pasta ja exista ele lista os arquivos existentes(errado mas apenas para gerar um erro)
     */
    public void criaPasta() {
        try {
            File PastaQueSalvaAsFichas = new File("PastaQueSalvaAsFichas");
            File[] oi = PastaQueSalvaAsFichas.listFiles();
            //serve para listar o arquivo inteiro
            for (File fileTmp : oi) {
                System.out.println(fileTmp.getName());
            }
        } catch (NullPointerException e) {
            File oi = new File("PastaQueSalvaAsFichas");
            oi.mkdir();
        }
    }

    //essa funcao serve apenas para gravar um texto escrito na linha(ainda precisa ser melhor implementado)
    public void gravar(String[] nomes, String[] classes, int tamanho, int players) throws IOException {
        Scanner bot = new Scanner(System.in);

        //o usuario insere um nome para o arquivo txt
        System.out.println("insira o nome que deseja para o arquivo");

        String txt = bot.nextLine();

        //cria um arquivo txt que o usuario escolhe o nome)(caso ja exista ele sobrescreve)
        FileWriter arq = new FileWriter(("PastaQueSalvaAsFichas/" + txt + ".txt"));
        PrintWriter gravarArq = new PrintWriter(arq);

        //salva os dados necessarios para ler depois ou seja o numero de jogadores e quantas classes tem
        gravarArq.println(players);
        gravarArq.println(tamanho);

        //salva os vetores nome e conteudo total
        for (int i = 0; i < (tamanho * players); i++) {
            gravarArq.println(nomes[i] + "\n" + classes[i]);
        }

        arq.close();

        //so para confirmar que o arquivo foi salvo
        System.out.println("ficha salva");
    }

    //para apagar algum arquivo txt ou seja um save
    public void apaga(String arq) {
        arq = arq + ".txt";
        File pasta = new File("PastaQueSalvaAsFichas/");
        File[] arquivos = pasta.listFiles();

        int erro = 0;
        //para percorrer todos os arquivos da pasta
        for (File arquivo : arquivos) {
            //compara o nome recebido com o arquivo gerado
            if (arquivo.getName().equals(arq)) {
                //caso entre ele sobe um contador para saber se existe um arquivo
                arquivo.delete();
                erro++;
                break;
            }
        }
        //o programa da uma resposta caso o arquivo tenha sido apagado ou nao
        if (erro == 0) {
            System.err.println("nao foi encontrado nenhum earquivo com esse nome");
        } else {
            System.out.println("Save apagado");
        }
    }
    /*
    TODAS AS FUNÇOES ABAIXO SAO RELACIONADAS A LER O ARQUIVO TXT
     */

    //essa funcao serve para imprimir no terminal todos os dados
    public String[] le(String txt) {
        //é preciso um retorno para essa funcao por isso foi criado essa String de erro(pode ser implementada melhor depois)
        String[] erro = new String[1];
        txt = txt + ".txt";
        try {
            //le um arquivo com o nome recebido(nao necessario inrerir o formato)
            FileReader ler = new FileReader(("PastaQueSalvaAsFichas/" + txt));
            BufferedReader lerArq = new BufferedReader(ler);
            //crio uma String inicial para ler a 1ª linha(sera usada para ler todas no decorrer do codigo)
            String fim = lerArq.readLine();
            /*as 3 linhas a seguir transformam as 2 primeiras linhas do codigo em int
            a 1ª linha é a quantidade de jogadores
            a 2ª linha é a quantidade de atributos que cada um tem no total(incluindo HP,NOME...)
             */
            int numJogadores = Integer.parseInt(fim);
            fim = lerArq.readLine();
            int numClasses = Integer.parseInt(fim);

            /*
            cria-se 2 vetores de String para guardar cada tipo de dado, podendo ser util mais para frente
             */

            //cria 2 vetores com o tamanho certinho
            SizeAjustado = numClasses * numJogadores;
            String[] nome = new String[SizeAjustado];
            String[] val = new String[SizeAjustado];

            /*
            as 3 linhas a seguir sao contadores e para andar mais uma vez a linha
             */
            fim = lerArq.readLine();
            int Cnome = 0;
            int Cval = 0;
            /*
            um for que ira ler 100% dos dados a partir dos dados pegados anteriormente
            salvando em cada vetor ou o nome da classe ou o valor(em String)
             */
            for (int j = 0; j < ((numClasses * 2) * numJogadores); j++) {
                if (j % 2 != 0) {
                    val[Cval] = fim;
                    Cval++;
                } else if (j % 2 == 0) {
                    nome[Cnome] = fim;
                    Cnome++;
                }
                fim = lerArq.readLine();
            }
            //basicamente seta valores
            NomeClasse = nome;
            ValorClasse = val;
            //nao sei por que é preciso a linha abaixo mas ela tem que existir
            ler.close();

            //basicamente aqui serve para caso de um erro em algo a cima
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }
        //volta a string de erro criada la em cima(nao tem nada nela(por enquanto))
        return erro;
    }

    //lista todos os arquivos dentro da nossa pasta personalisada
    public void listar() {
        File PastaQueSalvaAsFichas = new File("PastaQueSalvaAsFichas/");
        File[] oi = PastaQueSalvaAsFichas.listFiles();
        //serve para listar o arquivo inteiro
        int contador = 0;
        for (File fileTmp : oi) {
            contador++;
            /*por algum motivo estava gerando um aquivo dentro chamado ".DS_Store" por isso essa sentenca
            para nao aparecer ou seja ignorar
             */
            if (fileTmp.getName().equals(".DS_Store")) {
            } else {
                //para imprimir tudo
                System.out.println(fileTmp.getName());
            }
        }
        if (contador == 0) {
            System.out.println("nao existem arquivos atualmente");
        }
    }

    public String[] getNomeClasse() {
        return NomeClasse;
    }

    public String[] getValorClasse() {
        return ValorClasse;
    }

    public int getSizeAjustado() {
        return SizeAjustado;
    }

    private int SizeAjustado;
    private String[] NomeClasse;
    private String[] ValorClasse;
}